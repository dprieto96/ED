Esta implementacion de diccionario utiliza el TAD Pila (archivo pila.h).
Por tanto, siempre que se use esta implementacion debe incluirse tambien
"pila.h" en el proyecto.