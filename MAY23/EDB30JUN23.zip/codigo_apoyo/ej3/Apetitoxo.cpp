/**
  NOMBRE Y APELLIDOS:
  USUARIO DE DOMJUDGE USADO EN EL EXAMEN:
*/

#include "Apetitoxo.h"


/**
 COMPLEJIDAD: Determina y justifica aqu� la complejidad de la operaci�n

*/
Apetitoxo::Apetitoxo() {
	// A IMPLEMENTAR

}


/**
 COMPLEJIDAD: Determina y justifica aqu� la complejidad de la operaci�n

*/
void Apetitoxo::annadeSolicitud(tDni dni, tFecha fecha) {
	// A IMPLEMENTAR

}


/**
 COMPLEJIDAD: Determina y justifica aqu� la complejidad de la operaci�n

*/
tFecha Apetitoxo::enEspera(tDni dni) const {
	// A IMPLEMENTAR

}


/**
 COMPLEJIDAD: Determina y justifica aqu� la complejidad de la operaci�n

*/
void Apetitoxo::primeroEnEspera(tDni& dni) const {
	// A IMPLEMENTAR

}


/**
 COMPLEJIDAD: Determina y justifica aqu� la complejidad de la operaci�n

*/
bool Apetitoxo::atiendeSolicitud() {
	// A IMPLEMENTAR

}


/**
 COMPLEJIDAD: Determina y justifica aqu� la complejidad de la operaci�n

*/
bool Apetitoxo::disponible(tFecha fecha) const {
	// A IMPLEMENTAR

}


/**
 COMPLEJIDAD: Determina y justifica aqu� la complejidad de la operaci�n

*/
Lista<tReserva> Apetitoxo::reservas() const {
	// A IMPLEMENTAR

}


/**
 COMPLEJIDAD: Determina y justifica aqu� la complejidad de la operaci�n

*/
void Apetitoxo::cedePuesto(tDni dni_del_que_cede, tDni dni_nuevo, tFecha fecha_nuevo) {
    // A IMPLEMENTAR

}


	
