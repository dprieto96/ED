/*
NOMBRE Y APELLIDOS:

USUARIO DomJudge ASIGNADO:

*/

#include "yoMeVacuno.h"


/*
 DETERMINACION DE LA COMPLEJIDAD
 
*/
YoMeVacuno::YoMeVacuno(tAnio anio, tNumVacunas n) {
	 // A IMPLEMENTAR
}

/*
 DETERMINACION DE LA COMPLEJIDAD
 
*/
void YoMeVacuno::fija_Anio_NumVacunas(tAnio anio, tNumVacunas n) {
	 // A IMPLEMENTAR 

}

/*
 DETERMINACION DE LA COMPLEJIDAD
 
*/
void YoMeVacuno::registra_centro(tIdCentro id, tDireccion dir) {
 // A IMPLEMENTAR 
 
}

/*
 DETERMINACION DE LA COMPLEJIDAD
 
*/
void YoMeVacuno::registra_ciudadano(tIdCiudadano id, tAnio anio) {
 // A IMPLEMENTAR 

}

/*
 DETERMINACION DE LA COMPLEJIDAD
 
*/
void YoMeVacuno::pide_cita(tIdCiudadano id) {
	// A IMPLEMENTAR
}

/*
 DETERMINACION DE LA COMPLEJIDAD
 
*/
bool YoMeVacuno::en_espera() {
	// A IMPLEMENTAR

}

/*
 DETERMINACION DE LA COMPLEJIDAD
 
*/
Lista<Asignacion> YoMeVacuno::atiende_solicitudes() {
	// A IMPLEMENTAR

}

/*
 DETERMINACION DE LA COMPLEJIDAD
 
*/
bool YoMeVacuno::administra_vacuna(tIdCentro idCentro) {
// A IMPLEMENTAR

}
